import Sidebar from '@/components/dashboard/Sidebar';
import ManageQuestions from '@/components/questions/QuestionManagement';

export default function Page() {
  return (
    <main className="min-h-screen flex  p-8 bg-gray-100">
         <Sidebar/>
         <ManageQuestions/>
    </main>
  );
}
