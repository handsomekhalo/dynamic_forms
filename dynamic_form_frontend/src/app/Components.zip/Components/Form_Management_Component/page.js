import Sidebar from "../../../components/dashboard/Sidebar";
import Form_Management from "../../../components/forms/FormManagement";
export default function Page() {
  return (
    <main className="min-h-screen flex  p-8 bg-gray-100">
         <Sidebar/>
      <Form_Management />
    </main>
  );
}
