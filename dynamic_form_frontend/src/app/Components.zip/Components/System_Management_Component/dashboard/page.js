'use client';

import React from 'react';
import Dashboard from '@/components/dashboard/Dashboard';

export default function DashboardPage() {
  return (
    <div className="p-8">
      <Dashboard />
    </div>
  );
}
